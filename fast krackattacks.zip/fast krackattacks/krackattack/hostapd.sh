#!/bin/bash
hostapd hostapd.conf $@
