This script is currently not actively supported. The documentation is also not complete.

Before running this script, you must compile hostapd. This only needs to be done once:

	  cd ../hostapd
	  cp defconfig .config
	  make -j 2

Then you can exece this script. See [our video](https://youtu.be/Oh4WURZoR98?t=47) for example commands.

